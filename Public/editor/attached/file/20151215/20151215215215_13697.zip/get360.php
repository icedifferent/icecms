<?php
/*
Author:胜永&&无道
Date:15-12-13
*/
error_reporting(0);
$rand=rand();
$r=empty($_GET['rand'])?$rand:$_GET['rand'];
$cookie_file="./360cookies/{$r}.txt";

if(isset($_GET['get_captcha'])){
	header("content-Type: image/png");
	echo Http_curl("https://passport.360.cn/captcha.php?m=create&app=i360&scene=login&userip=DUGIRzbKjNql2KFmM6FdCQ%3D%3D&level=default&sign=e8f4a7&r=1445656376","",array(),$head,$cookie);
	exit();
}
header("content-Type: text/html; charset=utf-8");

echo <<<HTML
<?xml version="1.0" encoding="utf-8"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8"/>
<meta http-equiv="Cache-control" content="no-cache" />
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>360cookie提取工具</title>
<link rel="stylesheet" type="text/css" href="../getcookie.css">
</head>
<body>
HTML;
if(!isset($_GET['account'])){

$txts=glob('360cookies/*');
foreach($txts as $txt){
if(file_exists($txt))@unlink($txt);
}
#print_r($txts);
echo <<<HTML
<div class="title">360用户cookie提取工具</div>
<form action='?' method='GET'>
<div class="content">用户名:<br/>
<input type="text" name="account" value="" class="txt"/><br/>
密   码:<br/>
<input type="text" name="password" value="" class="txt"/><br/>
验证码:<br/>
<input type="text" name="captcha" value="" class="txt"/><br/>
<input type="hidden" name="rand" value="{$r}" class="txt"/><br/>
<img src="?get_captcha&rand={$r}"/></img><br/>
<p><input type="submit" value='确定'/>
<input type="reset" value='重填'/></p>
</form>
</div>
</body></html>
HTML;
exit();
}



$account=empty($_GET['account'])?exit('请输入账号'):$_GET['account'];
$password=empty($_GET['password'])?exit('请输入密码'):md5($_GET['password']);
$captcha=empty($_GET['captcha'])?'':$_GET['captcha'];
// 获取Token
$body=Http_curl('http://login.360.cn/?o=sso&m=getToken&func=&userName={$account}','',array(),$head,$cookie);
$tmp=json_decode(getSubstr($body,"login.setSigCallback(",")"));
$token=$tmp->token?$tmp->token:exit('没有获取到Token');
// end 获取Token
//echo $token.'<hr>';

//提交登陆
$post="src=pcw_cloud&from=pcw_cloud&charset=UTF-8&requestScema=https&o=sso&m=login&lm=0&captFlag=1&rtype=data&validatelm=0&isKeepAlive=&captchaApp=i360&userName={$account}&type=normal&account={$account}&password={$password}&captcha={$captcha}&token={$token}&proxy=http%3A%2F%2Fyunpan.360.cn%2Fpsp_jump.html&callback=&func=";


$body=Http_curl("https://login.360.cn/",$post,array(),$head,$cookie);
$errmsg=getSubstr($body,"errmsg=","&");
$errdetail=getSubstr($body,"errdetail=","&");//这里面有验证码地址，不知道用不用得到
$userInfo=json_decode(urldecode(getSubstr($body,"userinfo=","&")));

if(empty($errmsg))
{
$resultStr=file_get_contents($cookie_file);
 echo '<textarea class="txt" name="" cols="30" rows="14">'.$resultStr.'</textarea> ';
	//没有错误信息
@unlink($cookie_file);
	#print_r($userInfo);
	exit();
}else{
echo <<<HTML

<div class="title">360用户cookie提取工具</div>
<form action='?' method='GET'>
<div class="content">用户名:<br/>
<input type="text" name="account" value="{$account}" class="txt"/><br/>
密  码:<br/>
<input type="text" name="password" value="" class="txt"/><br/>

<input type="hidden" name="rand" value="{$r}" class="txt"/><br/>
验证码:<br/>
<input type="text" name="captcha" value="" class="txt"/><br/>
<img src="?get_captcha&rand={$r}"/></img><br/>
<p><input type="submit" value='确定'/></p>
</form>
</div>
</body></html>
HTML;
}

//调试显示
echo $resultStr=urldecode($errmsg);
 
 
@unlink($cookie_file);


function Http_curl($url,$post='',$setHeader=array(),&$header='',&$cookie='')
	{
          global $cookie_file;

$cookie=@file_get_contents($cookie_file);
		$ch=curl_init($url);//初始化
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);// https请求 不验证证书
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);// https请求 不验证hosts
		//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);//禁止重定向
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);//返回结果
		curl_setopt($ch, CURLOPT_HEADER,true);//获取头部才能获取cookie
		//curl_setopt ($ch, CURLOPT_PROXY,"127.0.0.1:8888");
		
		if($post<>'')//Post
		{
				curl_setopt($ch, CURLOPT_POST,true);
				curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
		}

		if(!empty($setHeader))//自定义header
		{
			curl_setopt($ch, CURLOPT_HTTPHEADER,$setHeader);
		}
		curl_setopt($ch, CURLOPT_COOKIE,$cookie);
	   	//curl_setopt($ch, CURLOPT_REFERER, $url);//来源地址为访问的地址
	    $result=curl_exec($ch);

	    //echo $result;

	    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);//获取header长度
    	$header = substr($result, 0, $headerSize);//header,头部
    	//解析cookie
    	$rcookie='';
    	if(preg_match_all('/Set-Cookie:(.*);/iU', $header, $matches))
		{
		//有cookies返回
			foreach($matches[1] as $val){
				$tmp=explode('=',$val);
				if($tmp[1] != '""'){
					$rcookie.=$val.';';
				}
			}
			//自动保存Cookie
			file_put_contents($cookie_file, upCookie($cookie,$rcookie));
		}
		$cookie=rtrim($rcookie,";");//返回本次请求响应的Cookie
	    $body = substr($result, $headerSize);//body,网页内容
	    
	    if(curl_errno($ch))//有错误
		{
	    	$body=curl_error($ch);
		}
		curl_close($ch);//把它关掉，把它关掉
		return $body;//返回
	}
	function getSubstr($str, $leftStr, $rightStr)
	{
	    $left = strpos($str, $leftStr);
	    //echo '左边:'.$left;
	    $right = strpos($str, $rightStr,$left);
	    //echo '<br>右边:'.$right;
	    if($left < 0 or $right < $left) return '';
	    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
	}

	function upCookie($cookie1,$cookie2)
	{	
		if(strpos($cookie1,";") <0 ) $cookie1.=';';//只有一个cookie的情况
		if(strpos($cookie2,";") <0 ) $cookie2.=';';//只有一个cookie的情况
		$cookie1=explode(';',$cookie1);$cookie2=explode(';',$cookie2);
		if(empty($cookie1) || empty($cookie2)) return array();
		$array1=array();$array2=array();
		foreach($cookie1 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array1[$k[0]]=$k[1];
		}
		foreach($cookie2 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array2[$k[0]]=$k[1];
		}
		$Array=array_merge($array1,$array2);
		$cookie='';
		foreach($Array as $key=>$val){
			$cookie.=$key.'='.$val.';';
		}
		$cookie=rtrim($cookie,";");
		return $cookie;
	}