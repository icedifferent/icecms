<?php
//user数据表,并且数据表中有三个字段分别为user_id,user_name,user_pwd
include "conn.php";//连接数据库
include "sql.class.php";//引入sql类
$u=new sql('user');//实例化sql一个对象//其中"user"为要操作的数据表名


$data['user_name']='ICECMS';
$data['user_pwd']=123456;

$u->add($data);//这样就能够在数据库user表里面增加一条数据了

$u->select();//选出了数据,返回数组（$u->where($data)->limit(0,1)->order("by user_id desc")->select()）

$u->where($data)->del();//删除了数据返回影响行数

//更多操作，具体自测（对应的还有update ,get_one等）
//更多请看说明
?>
