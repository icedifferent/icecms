<?php
	/*网名：gz05岐山作品*/
	class Db{
		protected static $obj=NULL;//对象
		protected static $link=NULL;//数据库连接
		protected $tabName='';//数据表
		protected $fields='';//表的字段名
		protected $pri='';//表的主键
		protected $where='';//条件
		protected $limit='';//分页查询
		protected $sql = array(// 保存查询时用到的
				'field'=> '*',
				'tabName' => '',
				'where' => '',
				'group' => '',
				'order' => '',
				'limit' => ''
			);
		//定义一个构造方法
		private function __construct($tabName){

			$this->tabName=$tabName;

			self::$link=mysql_connect(HOST,USER,PWD) or die('连接数据库失败'.mysql_error() );

			mysql_select_db(DBNAME);

			mysql_set_charset('UTF8');

			//执行获取字段名
			$this->getField();
		}

		//定义一个静态方法来new一个对象出来
		public static function myConstruct($tabName){

			if(is_null(self::$obj))
				self::$obj = new self($tabName);

			return self::$obj;
		}

		//获取字段名，和主键
		protected function getField(){

			$sql="DESC {$this->tabName}";

			$result=mysql_query($sql);

			while($row=mysql_fetch_assoc($result)){
			
				$this->fields[]=$row['Field'];

				//获取表的主键
				if($row['Key']=='PRI'){
					$this->pri=$row['Field'];
				}
			}
		}


		//当找不到方法时，进来
		public function __call($funcName,$args){

			//判断是否是sql的关键字，若不是则过滤掉
			if(array_key_exists($funcName,$this->sql)){
				$this->sql[$funcName] = $args[0];
			}

			return $this;
		}


		//查询出所有的信息出来 
		public function select(){
			
			//判断sql['tabName']是否有数据，若没有，则用$tabName里的数据
			$tabName = !empty($this->sql['tabName'])?$this->sql['tabName']:$this->tabName;
			//拼接sql语句
			$sql="select {$this->sql['field']} from {$tabName} {$this->sql['where']} {$this->sql['group']} {$this->sql['order']} {$this->sql['limit']}";
			
			//把$this->sql的数据恢复原样
			$this->$sql = array(// 保存查询时用到的
				'field'=> '*',
				'tabName' => '',
				'where' => '',
				'group' => '',
				'order' => '',
				'limit' => ''
			);
			return $this->query($sql);

		}

		

		//自定义一个查询的发送sql语句
		protected function query($sql=null){
			$arr = array();
			
			if(!empty($sql) && is_string($sql)){
				$result = mysql_query($sql);
				if($result && mysql_num_rows($result)){
					while($row = mysql_fetch_assoc($result)){
						$arr[] = $row;
					}
				}
			}
			return $arr;
		}


		/**
		* 插入数据方法 insert()
		* @param $arr 数组  如：array('id'=>1,'name'=>'xiaosan')
		*/
		public function insert(array $arr){

			//判断sql['tabName']是否有数据，若没有，则用$tabName里的数据
			$tabName = !empty($this->sql['tabName'])?$this->sql['tabName']:$this->tabName;
			
			//判断是否有值 
			if(empty($arr)){
				return false;
			}

			$field = '';	//用于拼接字段的
			$values = '';	//用于拼接相对应的值的

			
			while(list($key,$val) = each($arr)){
				$field.="`{$key}`".',';
				$values.="'{$val}'".',';
			}
			$field = trim($field,',');
			$values = trim($values,',');
			
			$sql = "insert into {$tabName}({$field}) values({$values})";
		
			return $this->execu($sql);
		}

		//删除一个数据
		public function delete(){

			//判断sql['tabName']是否有数据，若没有，则用$tabName里的数据
			$tabName = !empty($this->sql['tabName'])?$this->sql['tabName']:$this->tabName;

			//拼接sql语句
			$sql="delete from {$tabName} {$this->sql['where']}";

			//还原sql['where']=''
			$this->sql['where'] = '';

			$result=$this->execu($sql);
			return $result;
		}

		//更新一个条数据
		public function update($arr){

			//判断sql['tabName']是否有数据，若没有，则用$tabName里的数据
			$tabName = !empty($this->sql['tabName'])?$this->sql['tabName']:$this->tabName;

			$str='';//用于拼接更改数据的

			while(list($key,$value)=each($arr)){
				$str.="{$key}='{$value}',";
			}

			$str=trim($str,',');

			$sql="update {$tabName} set {$str} {$this->sql['where']}";


			//还原sql['where']=''
			$this->sql['where'] = '';

			//发送sql语句
			$result=$this->execu($sql);
			return $result;
		}

		//增、删、改的发送方法
		protected function execu($sql=null){

			if(!empty($sql)){
				$result=mysql_query($sql);

				if($result){
					return mysql_insert_id() ? mysql_insert_id() : mysql_affected_rows();
				}else{
					return false;
				}
			}
		}

		

		//防止用户使用克隆
		public function __clone(){
			trigger_error('Clone is not allow');
			//die();
		}
		

	}