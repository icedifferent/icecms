<?php
/**
 * 科林程序操作类
 * @author 布衣
 * QQ 780998900
 */
class Kelink{
    /**
     * 结束帖子
     */
    const TOPIC_END   = 1;
    /**
     * 锁定帖子
     */
    const TOPIC_LOCK  = 2;
    /**
     * 解除结束
     */
    const TOPIC_END_CLEAN = 3;
    /**
     * 解除锁定
     */
    const TOPIC_LOCK_CLEAN = 4;
    /**
     * 删除帖子
     */
    const TOPIC_DELETE  = 5;
    /**
     * 网站域名
     * @var string
     */
    private $domain;
    /**
     * @var int
     */
    private $siteid;
    /**
     * @var string
     */
    private $username;
    /**
     * @var string
     */
    private $password;
    /**
     * cookie保存路径
     * 建议使用绝对路径
     * @var stirng
     */
    private $cookiePatth;
 
    /**
     * 初始化一些信息
     * @param $domain
     * @param $siteid
     * @param $username
     * @param $password
     * @param $cookiePath
     */
    public function __construct($domain, $siteid, $username, $password, $cookiePath){
        $this->domain      = $domain;
        $this->siteid      = $siteid;
        $this->username    = $username;
        $this->password    = $password;
        $this->cookiePatth = $cookiePath;
        if(! class_exists('Http')){
            exit('Class Http Not Found!');
        }
    }
 
    /**
     * 登录网站
     * @return bool
     */
    public function login(){
        $url = $this->domain .'/waplogin.aspx';
        $data = array(
            'action'  => 'login',
            'backurl' => '',
            'classid' => '0',
            'g'       => '%E7%99%BB%20%E5%BD%95',
            'logname' => $this->username,
            'logpass' => $this->password,
            'savesid' => '0',
            'sid'     => '-2-0-0-0-0',
            'siteid'  => $this->siteid
        );
        $ret = $this->_post($url, $data);
        if(stripos($ret, '登录成功')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 检查是否为登录状态
     * @return bool
     */
    public function is_login(){
        $ret = $this->_get($this->domain .'/myfile.aspx?siteid='. $this->siteid);
        if($this->Verify($ret)){
            return $this->is_login();
        }
        if(stripos($ret, '我的地盘')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 获取SID
     * @return bool
     */
    public function sid(){
        $ret = $this->_get($this->domain .'/myfile.aspx');
        if($this->Verify($ret)){
            return $this->sid();
        }
        if(stripos($ret, '登录网站')){
            return false;
        }else{
            if(preg_match('/&sid=(\S+)">/', $ret, $match)){
                return trim($match[1]);
            }else{
                return false;
            }
        }
    }
    /**
     * 签到
     * @param string $message 签到内容
     * @return bool
     */
    public function Signin($message){
        $url = $this->domain .'/Signin/Signin.aspx?Action=index&Mod=Signin&siteid='. $this->siteid;
        $data = array(
            'FaceSelect' => '',
            'content'    => $message,
            'g'          => '签到',
        );
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->Signin($message);
        }
        if(stripos($ret, '您今天获得') || stripos($ret, '您是今天第一个签到的哦') || stripos($ret, '您是第一次签到的哦')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 转币操作
     * @param int $id 接受人ID
     * @param int $sum 金额
     * @param string $message 原因
     * @return bool
     */
    public function toMoney($id, $sum, $message){
        $url  = $this->domain .'/bbs/toMoney.aspx';
        $data = array(
            'action'  => 'add',
            'g'       => '执行赠送',
            'remark'  =>  $message,
            'siteid'  => $this->siteid,
            'tomoney' => $sum,
            'touserid'=> $id,
            'type'    => '',
        );
 
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->toMoney($id, $sum, $message);
        }
        if(stripos($ret, '操作成功')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 新建一条内信
     * @param int $uid 接收人ID
     * @param string $content 内容
     * @param string $title 标题(可选)
     * @return bool
     */
    public function CreateMessage($uid, $content, $title = ''){
        $url  = $this->domain .'/bbs/messagelist_add.aspx';
        $data = array(
            'touseridlist' => $uid,
            'content'      => $content,
            'title'        => $title,
            'action'       => 'gomod',
            'classid'      => '0',
            'siteid'       => $this->siteid,
            'types'        => '2',
            'issystem'     => '',
        );
 
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->CreateMessage($uid, $content, $title);
        }
        if(stripos($ret, '发送信息成功')){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 获取帖子列表
     * @param int $page 页数
     * @param int $userid 指定用户ID
     * @param bool $detail 输出细节
     * @return array|bool
     */
    public function TopicList($page = 1, $userid = null, $detail = true){
        if(! is_numeric($userid)) {
            $url = $this->domain .'/bbs/book_list.aspx?action=new&siteid=' . $this->siteid . '&classid=0&page=' . $page;
        }else{
            $url = $this->domain .'/bbs/book_list.aspx?action=search&siteid='. $this->siteid .'&classid=0&key='. $userid .'&type=pub&page='. $page;
        }
        $ret = $this->_get($url);
        //处理数据
        if(preg_match('/<!--listS-->(.*)<!--listE-->/', $ret, $match)){
            if(preg_match_all('/view\.aspx\?id=(\d+)/', $match[1], $matchs)){
                $result = array();
                if($detail == true) {
                    foreach ($matchs[1] as $row) {
                        $result[] = $this->Topic($row);
                    }
                    return $result;
                }else{
                    return $matchs[1];
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
 
    /**
     * 获取某个帖子的信息
     * @param int $id 帖子id
     * @return array
     */
    public function Topic($id){
        $url = $this->domain .'/bbs/view.aspx?id='. $id;
        $ret = $this->_get($url);
        //处理数据
        preg_match('/<h2 class="titleview">(.*)<\/h2> <span class="subtitleview2">(.*)&nbsp;&nbsp;人气 (\d+)&nbsp;&nbsp;&nbsp;&nbsp;<a href="\S+classid=(\d+)\S+">(\S+)<\/a>/', $ret, $info);
        preg_match('/<!--listS-->(.*)<!--listE-->\s?<span/s', $ret, $content);
        preg_match('/<div class="name"><a href="(\S+)touserid=(\d+)">(<font color="\S+">(.*)<\/font>|.*)<\/a><span class="Sex">/', $ret, $author);
        $arr = array(
            'id'       => $id,
            'title'    => $info[1],
            'time'     => $info[2],
            'view'     => $info[3],
            'classid'     => array(
                'id'   => $info[4],
                'name' => $info[5]
            ),
            'content'  => $content[1],
            'author'   => array(
                'id'   => $author[2],
                'name' => array_key_exists(4, $author) ? $author[4] : $author[3], //处理彩名
            ),
        );
        return $arr;
    }
 
    /**
     * 获取帖子操作记录
     * 暂未实现
     * @param $id
     * @param $classid
     */
    public function TopicLog($id, $classid){
        $url = $this->domain .'/bbs/Book_View_log.aspx?siteid='. $this->siteid .'&classid='. $classid .'&id='. $id;
        $ret = $this->_get($url);
 
        preg_match('/<div class="subtitle">操作日志<\/div><div class="content">(.*)<\/div><div class="btBox">/', $ret, $content);
        print_r($content);
        //exit;
        $content = preg_replace('/<br\/>/', "\n", $content[1]);
        if(preg_match_all('/(.*)\(ID(\d+)\)(\S+)此帖(.*)/', $content, $match)){
            print_r($match);
        }else{
            echo '22';
        }
    }
 
    /**
     * 新建一个主题
     * @param string $title
     * @param string $content
     * @param int $classid
     * @return bool
     */
    public function CreateTopic($title, $content, $classid){
        $url = $this->domain .'/bbs/book_view_add.aspx';
        $data = array(
            'action' => 'gomod',
            'book_content' => $content,
            'book_title' => $title,
            'classid'    => $classid,
            'g'          => '发表贴子',
            'siteid'     => $this->siteid
        );
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->CreateTopic($title, $content, $classid);
        }
        if(stripos($ret, '发表主题成功')){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 操作帖子
     * @param int $type 操作类型
     * @param int $id 帖子id
     * @param int $classid 贴子所在版块ID
     * @param string $message 理由
     * @return bool
     */
    public function OperationTopic($type, $id, $classid, $message = null){
        $switch = false;
        switch($type) {
            case self::TOPIC_END:
                $url_type = 'end';
                $tops = 2;
                $status = '结束成功';
                break;
            case self::TOPIC_END_CLEAN:
                $url_type = 'end';
                $tops = 0;
                $status = '取消结束成功';
                break;
            case self::TOPIC_LOCK:
                $url_type = 'lock';
                $tops = 1;
                $status = '锁定成功';
                break;
            case self::TOPIC_LOCK_CLEAN:
                $url_type = 'lock';
                $tops = 0;
                $status = '取消锁定成功';
                break;
            case self::TOPIC_DELETE:
                $url = $this->domain . '/bbs/book_view_del.aspx?why=' . urlencode($message) . '&siteid=' . $this->siteid . '&classid=' . $classid . '&id=' . $id . '&action=Del_1';
                $status = '删除成功';
                $switch = true;
                break;
        }
        if($switch === true){
            $ret = $this->_get($url);
        }else {
            $url = $this->domain . '/bbs/book_view_' . $url_type . '.aspx';
            $data = array(
                'action' => 'gomod',
                'classid' => $classid,
                'g' => '确 定',
                'id' => $id,
                'siteid' => $this->siteid,
                'tops' => $tops,
                'whylock' => $message,
            );
            $ret = $this->_post($url, $data);
        }
        if($this->Verify($ret)){
            return $this->OperationTopic($type, $id, $classid, $message);
        }
        if(stripos($ret, $status)){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 编辑帖子
     * @param int $tid 帖子ID
     * @param int $classid 帖子所在版块ID
     * @param string $title 标题
     * @param string $content 内容
     * @return bool
     */
    public function EditTopic($tid, $classid, $title, $content){
        $url = $this->domain .'/bbs/book_view_mod.aspx';
 
        $data = array(
            'action'       => 'gomod',
            'book_content' => $content,
            'book_img'     => '',
            'book_title'   => $title,
            'bt'           => '修 改',
            'classid'      => $classid,
            'face'         => '',
            'id'           => $tid,
            'siteid'       => $this->siteid,
            'stype'        => '',
            'viewmoney'    => '0',
            'viewtype'     => '0',
        );
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->EditTopic($tid, $classid, $title, $content);
        }
        if(stripos($ret, '修改成功')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 新建一条回复
     * @param int $tid
     * @param string $content
     * @param int $classid
     * @return bool
     */
    public function CreateComment($tid, $content, $classid){
        $url = $this->domain .'/bbs/book_re.aspx';
        $data = array(
            'action'  => 'add',
            'classid' => $classid,
            'content' => $content,
            'g'       => '提交中...',
            'id'      => $tid,
            'sendmsg' => '0',
            'siteid'  => $this->siteid,
        );
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->DeleteComment($tid, $content, $classid);
        }
        if(stripos($ret, '回复成功')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 删除回复
     * @param int $tid
     * @param int $reid
     * @param int $classid
     * @return bool
     */
    public function DeleteComment($tid, $reid, $classid){
        $url = $this->domain .'/bbs/book_re_del.aspx?action=godel&reid='. $reid .'&id='. $tid .'&siteid='. $this->siteid .'&classid='. $classid .'&ot=0';
        $ret = $this->_get($url);
        if($this->Verify($ret)){
            return $this->DeleteComment($tid, $reid, $classid);
        }
        if(stripos($ret, '删除成功')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 加黑用户
     * @param $uid
     * @param $classid
     * @param $toclassid
     * @param $days
     * @return bool
     */
    public function lockUser($uid, $classid, $toclassid, $days){
        $url  = $this->domain .'/bbs/lockuser_list_add.aspx';
        $data = array(
            'action' => 'gomod',
            'backurlid' => '1',
            'classid'   => $classid,
            'g'         => '提 交',
            'id'        => '',
            'lockdate'  => $days,
            'siteid'    => $this->siteid,
            'toclassid' => $classid,
            'touserid'  => $uid,
        );
 
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->lockUser($uid, $classid, $toclassid, $days);
        }
        if(stripos($ret, '添加成功')){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 解除加黑
     * @param int $uid 用户ID
     * @return bool
     */
    //public function lockUserClean($uid){
        //$url = $this->domain .'/bbs/LockUser_List_del.aspx?action=godel&delid=148&id=&siteid=1000&classid=268&backurlid=1&touserid=43763&toclassid=268';
    //}
    /**
     * 新建一篇文章
     * @param int $classid         所在的classid
     * @param int $toclassid       需要发布的classid
     * @param string $title        标题
     * @param string $content      内容
     * @param string $author       作者
     * @param string $pub          来源
     * @param string $keywords     关键字
     * @param string $descriptions 描述
     * @param string $img          压缩图
     * @return bool                发布状态
     */
    public function CreateArticle($classid, $toclassid,
                                  $title, $content,
                                  $author = '',
                                  $pub = '',
                                  $keywords = '',
                                  $descriptions = '',
                                  $img = ''){
        $url  = $this->domain .'/article/admin_WAPadd.aspx';
        $data = array(
            'toclassid'    => $toclassid,
            'book_title'   => $title,
            'book_author'  => $author,
            'book_pub'     => $pub,
            'keywords'     => $keywords,
            'descriptions' => $descriptions,
            'book_img'     => $img,
            'book_content' => $content,
            'action'       => 'gomod',
            'classid'      => $classid,
            'siteid'       => $this->siteid,
        );
        $ret = $this->_post($url, $data);
        if($this->Verify($ret)){
            return $this->CreateArticle($classid, $toclassid, $title, $content, $author, $pub , $keywords, $descriptions, $img);
        }
        if(stripos($ret, 'Success')){
            return true;
        }else{
            return false;
        }
    }
 
    /**
     * 删除文章
     * @param $id
     * @param $classid
     * @return bool
     */
    public function DeleteArticle($id, $classid){
        $url = $this->domain .'/article/admin_WAPdel.aspx?action=godel&id='. $id .'&siteid='. $this->siteid .'&classid='. $classid;
        $ret = $this->_get($url);
        if($this->Verify($ret)){
            return $this->DeleteArticle($id, $classid);
        }
        if(stripos($ret, '删除成功')){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 检查是否需要输入二次密码
     * @param $ret
     * @return bool
     */
    public function Verify($ret){
        if(stripos($ret, '请输入您的密码')){
            preg_match('/<form name="go" action="(\S+)" method="post">输入密码/', $ret, $url);
            $data = array(
                'needpassword' => $this->password,
                'siteid'       => $this->siteid,
            );
            $ret = $this->_post($url[1], $data);
            if(stripos($ret, '请输入您的密码')){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }
    /**
     * POST方法
     * @param string $url 请求URL
     * @param array|string $data 数据包
     * @return string 网页
     */
    public function _post($url, $data){
        $http = Http::Open($url, 10);
        $http->CookieFile($this->cookiePatth);
        $http->post($data);
        $res = $http->execute();
        $ret = $res->body('utf-8');
 
        return $ret;
    }
 
    /**
     * GET方法
     * @param string $url 请求url
     * @return string 网页
     */
    public function _get($url){
        $http = Http::Open($url, 10);
        $http->CookieFile($this->cookiePatth);
        $res = $http->execute();
        $ret = $res->body('utf-8');
 
        return $ret;
    }
}

