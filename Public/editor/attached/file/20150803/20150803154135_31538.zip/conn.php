<?php
		$conn = @mysql_connect("localhost","root","root");
		if (!$conn){
			die("连接数据库失败：" . mysql_error());
		}
		mysql_select_db("sqltest", $conn);
		mysql_query("SET NAMES utf8");
		mysql_query("set character_set_client=utf8"); 
		mysql_query("set character_set_results=utf8");
