<?php
/*
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
         佛祖保佑       永无BUG
*/
########### 2015 12 2   更新  #####################
// by:胜永

/*使用例子

header("content-Type:text/html;charset=utf-8");
$c=new CurlLib();

//来设置一些header
$header='User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0
X-Requested-With: XMLHttpRequest
Referer: http://awby.cn/';

$c->SetHeader($header,"\r\n");//设置header
$c->SetCookie('sid=q55gkrokvsuvbaa63int0i218ufp2a5i;user=username');//设置cookie,也可以在设置header的时候设置
//$c->SetProxy("127.0.0.1:8888");//设置代理
$c->SetMethod('GET');//请求方式,默认GET
$c->SetMaxredirs(30);//设置重定向 限制次数

$c->send("http://awby.cn",null);//发生请求

echo '<pre>'.$c->getRequestHeader().'</pre><hr>';//看看curl发送的header是什么
echo '<pre>'.$c->getResponseHeader().'</pre><hr>';//看看响应的header是什么
echo '<pre>'.$c->getResponseCookie().'</pre><hr>';//看看响应的Cookie是什么
echo '<pre>'.htmlspecialchars($c->getResponseBody()).'</pre><hr>';//看看响应的内容是什么.自动utf-8编码
*/

Class CurlLib
{
	private $ch;
	private $HeaderSize=0;
	private $method='GET';

	public $RequestQuery=null;
	public $Response=null;

	function __construct()
	{
		$this->ch=curl_init();
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);// https请求 不验证证书
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);// https请求 不验证hosts
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);//返回结果
		curl_setopt($this->ch, CURLOPT_HEADER,true);//获取头部才能获取cookie
		curl_setopt($this->ch, CURLINFO_HEADER_OUT, true);//请求追踪
		curl_setopt($this->ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($this->ch, CURLOPT_AUTOREFERER, true);//自动设置Referer
	}

	function __destruct()
	{
		curl_close($this->ch);
	}

	public function SetMaxredirs($max=null)//设置重定向 限制次数
	{
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);//重定向
		if(!empty($max) and (int)$max <= 30)
		{
			curl_setopt($this->ch, CURLOPT_MAXREDIRS, $max);
		}else{
			curl_setopt($this->ch, CURLOPT_MAXREDIRS, 30);
		}
	}

	public function SetMethod($method)//设置请求方式
	{
		$method=strtoupper($method);
		$this->method=$method;

		if($method == 'GET' || $method =='POST' || $method =='HEAD')
		{
			curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, $method);
			if($method == 'HEAD')
			{
				curl_setopt($this->ch, CURLOPT_NOBODY, true);
			}
		}
	}
	public function SetProxy($proxy)//设置代理
	{
		if(!empty($proxy)){
			curl_setopt($this->ch,CURLOPT_PROXY,$proxy);
		}
	}
	public function SetHeader($header,$exp=PHP_EOL)//设置header
	{
		$this->Request_Header=$header;
		if(is_array($header)){
			curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
		}else{
			curl_setopt($this->ch, CURLOPT_HTTPHEADER, explode($exp, $header));
		}
		
	}

	public function SetCookie($cookie)//设置Cookie,也可以在设置header的时候设置
	{
		if(!empty($cookie)){
			curl_setopt($this->ch,CURLOPT_COOKIE,$cookie);
		}
	}

	public function Send($url,$data=null)//发送请求
	{
		curl_setopt($this->ch,CURLOPT_URL,$url);

		if($this->method == 'POST' and $data !== null)//需要发送数据
		{
			if(is_array($data)){
				foreach ($data as $key => $value) {
					$this->RequestQuery.=$key.'='.$value.'&';
				}
				$this->RequestQuery=rtrim($this->RequestQuery,'&');
			}else{
				$this->RequestQuery=$data;
			}
			curl_setopt($this->ch, CURLOPT_POST,true);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS,$data);
			//curl_setopt($this->ch, CURLOPT_POSTFIELDS,$this->RequestQuery);
		}

		$this->Response=curl_exec($this->ch);
		$this->HeaderSize = curl_getinfo($this->ch, CURLINFO_HEADER_SIZE);//获取header长度

	}

	public function getRequestHeader()//获取curl发送的header
	{
		return curl_getinfo($this->ch, CURLINFO_HEADER_OUT).$this->RequestQuery;
	}

	public function getResponseHeader()//获取响应的header
	{
		return rtrim(substr($this->Response, 0, $this->HeaderSize),"\r\n\r\n");
	}

	public function getResponseCookie()//获取响应的cookie
	{
		$Cookie='';
		if(preg_match_all('/Set-Cookie:([^;]+);/', $this->getResponseHeader(), $matches))
		{
			foreach($matches[1] as $val)
			{
				$Cookie.=$val.';';
			}
			return rtrim($Cookie,";");
		}		
	}

	public function getResponseBody()//获取响应的内容
	{
		$Body='';
		$Body = substr($this->Response, $this->HeaderSize);

		if(empty($Body))
		{
			$Body="出错：".curl_error($this->ch);
		}

		$charset=$this->GetSubstr(curl_getinfo($this->ch,CURLINFO_CONTENT_TYPE),"charset=","-");//获取编码

		if($charset == ""){
			$charset=$this->GetSubstr($Body,"charset=",'-');
		}

		//echo $charset;
		if($charset !== "utf")
		{
			$Body=mb_convert_encoding($Body, 'utf-8', 'gbk');//转码
		}
		return $Body;
	}

	public function GetSubstr($str, $leftStr, $rightStr)//取文本中间
	{
	    $left = strpos($str, $leftStr);
	    //echo '左边:'.$left;
	    $right = strpos($str, $rightStr,$left);
	    //echo '<br>右边:'.$right;
	    if($left < 0 or $right < $left) return '';
	    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
	}

	public function GetNewCookie($cookie1,$cookie2)//两个Cookie合并更新为一个
	{	
		if(strpos($cookie1,";") <0 ) $cookie1.=';';//只有一个cookie的情况
		if(strpos($cookie2,";") <0 ) $cookie2.=';';//只有一个cookie的情况
		$cookie1=explode(';',$cookie1);$cookie2=explode(';',$cookie2);
		if(empty($cookie1) || empty($cookie2)) return array();
		$array1=array();$array2=array();
		foreach($cookie1 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array1[$k[0]]=$k[1];
		}
		foreach($cookie2 as $val){
			$k=explode("=",$val);
			if(count($k)<2) continue;
			$array2[$k[0]]=$k[1];
		}
		$Array=array_merge($array1,$array2);
		$cookie='';
		foreach($Array as $key=>$val){
			$cookie.=$key.'='.$val.';';
		}
		$cookie=rtrim($cookie,";");
		return $cookie;
	}
}
?>