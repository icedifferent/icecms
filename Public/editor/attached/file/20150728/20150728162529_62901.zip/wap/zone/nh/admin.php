<?php
include("../good.php");
include("../../conn.php");
if($_COOKIE["uid"]!=1)
{
die("Not Allow!");
}

?>