﻿<?php
$css=file_get_contents(dirname(__FILE__)."/css.css");