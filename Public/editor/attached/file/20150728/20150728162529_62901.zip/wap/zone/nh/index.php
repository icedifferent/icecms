<?php
header("Location:list.php");
?>