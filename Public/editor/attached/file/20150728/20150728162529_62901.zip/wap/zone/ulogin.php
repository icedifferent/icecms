<?php
setcookie("uid","",time()-3600);
header("location:index.php");
?>