<?php 
include(dirname(__file__)."/good.php");