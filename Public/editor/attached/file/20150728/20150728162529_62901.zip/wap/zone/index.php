<?php
header("location:all_list.php");
