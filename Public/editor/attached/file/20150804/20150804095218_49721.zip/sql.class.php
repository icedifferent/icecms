<?php
/*
 *MYSQL CLASS
 *webiste :http://www.icecms.cn
 *2015/8/3
 *suggest use array() so that you can defence the xss in a extent;
 */
class sql{
	public function __construct($table=NULL){
		$this->table=$table;
		$this->limit_where=-1;
	}
	private $where;
	private $table;
	private $sql;
	private $order;
	private $limit_num;
	private $limit_where;
	private $mysql_query_result;

	/*"$where" canbe array() or string 
	 *"$boo" is a value canbe selected
	 *return $this;
 	*/
	public function where($where,$boo='and'){
		if(is_array($where)){
			$i=0;
			$value='';
			$boos='';
			$string='';
			foreach($where as $key=>$datas){
				if($i!=0){
					$boos=$boo;
				}
				$key=mysql_real_escape_string($key);
				$datas=mysql_real_escape_string($datas);
				$this->where=$string=$string." ".$boos."`".$key.'` ="'.$datas.'"';
				$i++;
			}
		}else{
			$this->where=mysql_real_escape_string($where);
		}
	 	return $this;
	}


	public function order($bywhat){
		$this->order=$bywhat;
	 	return $this;
	}

	/*
	 *"$where" stand for the first place where you start
	 *"$num" is the number you wanted to select
	 *return $this;
	 */
	public function limit($where=0,$num=1){
		$this->limit_where=(int)$where;
		$this->limit_num=(int)$num;
	 	return $this;
	}

	/*"$data" can be array() or string;
	 *return the number of affected_rows;
	 *
	 */
	public function update($data){
		$i=0;
		$dot='';
		$string='';
		if(!is_array($data)){
			//$data=mysql_real_escape_string($data);
			$this->sql=$sql = "update `".$this->table."` set  $data where($this->where)";
		}else{
			foreach($data as $key=>$datas){
				if($i!=0){
				   $dot=',';
				}
				$key=mysql_real_escape_string($key);
				$datas=mysql_real_escape_string($datas);
				$string=$string.$dot."`".$key.'` ="'.$datas.'"';
				$i++;
			}
			$this->sql=$sql = "update `".$this->table."` set  $string where($this->where)";
		}
		mysql_query($sql);
		return mysql_affected_rows();
	}

	/*
	 *"$data" must be array()，the key of array() is the name of  column
   	 *return return the number of affected_rows;
	 *
	 */
	public function add($data){
		$i=0;
		$dot='';
		$column='';
		$value='';
		foreach($data as $key=>$datas){
			if($i!=0){
			   $dot=',';
			}
			$key=mysql_real_escape_string($key);
			$datas=mysql_real_escape_string($datas);
			$column=$column.$dot."`".$key."`";
			$value=$value.$dot.'"'.$datas.'"';
			$i++;
		}
		$this->sql=$sql = "insert into `".$this->table."` ($column) values ($value)";
		mysql_query($sql);
		return mysql_affected_rows();
	}

      /*
       *"$what" is the name of  column
       * return value;
       *
       */
	public function get_one($what){
	       $what=mysql_real_escape_string($what);
	       $this->sql=$sql = "select `$what` from `".$this->table."`  where($this->where)";
	       $result=$this->mysql_query_result=mysql_query($sql);
	       $r=mysql_fetch_array($result);
	       return $r[0];
	}
	

	/*
       *
       * return array();
       *
       */
	public function select($data=-1){
		$o='';
		$l='';
		$w='';
		$i=0;
		if($this->order!=''){
			$o=" order ".$this->order ;
		}
		if($this->limit_where!=-1){
			$l= " limit ".$this->limit_where.",".$this->limit_num;
		}
		if($this->where!=''){
			$w="where (".$this->where.")";
		}
		if(is_array($data)){
			$i=0;
			$dot='';
			$string='';
			foreach($data as $key=>$datas){
				if($i!=0){
				   $dot=',';
				}
				//$key=mysql_real_escape_string($key);
				$datas=mysql_real_escape_string($datas);
				$string=$string.$dot."`".$datas.'`';
				$i++;
			}
			$this->sql=$sql = "select $string from `".$this->table."` $w $o $l ";
		}else if($data!=-1){
			$this->sql=$sql = "select $data from `".$this->table."` $w $o $l ";
		}else{
			$this->sql=$sql = "select * from `".$this->table."` $w $o $l ";
		}
	        $result=$this->mysql_query_result=mysql_query($sql);
		while($k=mysql_fetch_array($result)){
			$arr[$i]=$k;
			$i++;
		}
		return $arr;
	}
	
	/*
	 *
	 *return return the number of affected_rows;
	 */
	public function del(){
		$w='';
		if($this->where!=''){
			$w="where (".$this->where.")";
		}
		$this->sql=$sql = "delete  from `".$this->table."` $w ";
		mysql_query($sql);
		return mysql_affected_rows();
	}

	//return number of selecting
	public function cot(){
		$this->select();
		return mysql_num_rows($this->mysql_query_result);
	}
	
	/*
	 * success return 1;
	 * error return null;
	 */
	public function createdb($dbname){
		$this->sql=$sql = "create DATABASE `".$dbname."` ";
		return mysql_query($sql);
		
	}


	/*
	 * success return 1;
	 * error return null;
	 */
	public function dropdb($dbname){
		$this->sql=$sql = "drop  DATABASE `".$dbname."` ";
		return mysql_query($sql);
		
	}

	/*
	 * success return 1;
	 * error return null;
	 */
	public function droptb($tbname){
		$this->sql=$sql = "drop table `".$tbname."` ";
		return mysql_query($sql);
		
	}

	/*
	 * success return 1;
	 * error return null;
	 */
	public function createtb($tbname){
		$this->sql=$sql = "create table `".$tbname."` ";
		return mysql_query($sql);
		
	}


	/*
	 *return the last sql you  executed
	 *
	 */
	public function getsql(){
		return $this->sql;
	}
}
