<?php if (!defined('THINK_PATH')) exit();?>

<!--
苍茫的代码是我的爱！！！
-->
<!DOCTYPE HTML>
<html xmlns:wb=“http://open.weibo.com/wb”>
<head>
<meta charset="UTF-8">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta http-equiv="X-UA-Compatible" content="IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<link href="/favicon.ico" rel="icon" type="image/x-icon" />
<meta name="robots" content="noindex,follow" />
<link rel='stylesheet' id='style-css'  href='http://www.bingduba.com/wp-content/themes/Git/style.css' type='text/css' media='all' />
<script type='text/javascript' src='/ice4/Public/webjs/jquery.min.js'></script>
<meta name=Copyright Content="本程序版权归ICE所有"/> 
<meta name="Author-Corporation" content="ICE,2015"/>
<meta name="description" content="ICECMS,PHP的讨论和交流"/>
<meta name="keywords" content="编程|PHP|C语言|c++|java|ice|icecms"/>
<meta name="description" content="">
<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url('/ice4/Public/webcss/bg.png'); background-repeat: repeat; background-position: top left; background-attachment: scroll; }
</style>
<script>
window._deel = {name: 'ICECMS',url: 'http://www.icecms.cn', ajaxpager: '', commenton: 0, roll: [0,0]}
</script>
<!--[if lt IE 9]><script src="/ice4/Public/webjs/html5.js"></script><![endif]-->

<title><?php echo ($user_name); ?>的空间</title>

</head>
<script language ="javascript" type ="text/javascript">
function atAdd(at){
	var content =document.getElementsByName("content")[0];
	content.value+="@"+at+",";
}


function urlAdd(){
	var content =document.getElementsByName("content")[0];
	content.value+="[url=http://链接地址]点击访问[/url]";
}


function imgAdd(){
	var content =document.getElementsByName("content")[0];
	content.value+="[img]http://图片地址[/img]";
}


function codeAdd(){
	var content =document.getElementsByName("content")[0];
	content.value+="[code]//请在这里输入代码[/code]";
	}
</script>
<style>
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}</style>
<body>
<body class="archive category category-android-articles category-18 custom-background">
	<header id="header" class="header" style="background-color: #616161;">
	<style type="text/css">#nav-header{background-color: rgba(85,84,85, 0.5);background: rgba(85,84,85, 0.5);color: rgba(85,84,85, 0.5);}</style>
	<style type="text/css">.navbar .nav li:hover a, .navbar .nav li.current-menu-item a, .navbar .nav li.current-menu-parent a, .navbar .nav li.current_page_item a, .navbar .nav li.current-post-ancestor a,.toggle-search ,#submit ,.btn,.pagination ul>.active>a,.pagination ul>.active>span,.bdcs-container .bdcs-search-form-submit{background: #616161;}.footer,.title h2{color: #616161;}.bdcs-container .bdcs-search-form-submit ,.bdcs-container .bdcs-search {border-color: #616161;}.pagination ul>li>a:hover,.navbar .nav li a:focus, .navbar .nav li a:hover,.toggle-search:hover,#submit:hover,.btn:hover{background-color: #474747;}</style><style type="text/css">.avatar{-webkit-transition:0.4s;-webkit-transition:-webkit-transform 0.4s ease-out;transition:transform 0.4s ease-out;-moz-transition:-moz-transform 0.4s ease-out;}.avatar:hover{transform:rotateZ(360deg);-webkit-transform:rotateZ(360deg);-moz-transform:rotateZ(360deg);}</style>
<div class="container-inner"><div align="center" class="g-logo"><a href="/"><h1><span class="g-mono" style="font-family:楷体;">WWW.ICECMS.CN</span>  <span class="g-bloger" style="font-family:楷体;">要有最朴素的生活和最遥远的梦想</span></h1></a></div></div><div id="toubuads"></div>
<div id="nav-header" class="navbar" style="border-bottom: 4px solid #616161 ;">
<style type="text/css">.bdsharebuttonbox a{cursor:pointer;border-bottom:0;margin-right:5px;width:28px;height:28px;line-height:28px;color:#fff}.bds_renren{background:#94b3eb}.bds_qzone{background:#fac33f}.bds_more{background:#40a57d}.bds_weixin{background:#7ad071}.bdsharebuttonbox a:hover{background-color:#7fb4ab;color:#fff;border-bottom:0}</style>
<ul class="nav">

<li id="menu-item-8" class="menu-item menu-item-type-taxonomy menu-item-object-category current-menu-item menu-item-has-children menu-item-13">
	<a href="/ice4/index.php/Home/Bbs/new_post">首页</a>
	<ul class="sub-menu">
		<li id="menu-item-9" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/1">杂谈茶楼</a></li>
		<li id="menu-item-10" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-10">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/5">WEB/PHP/ASP/C#交流</a></li>
		<li id="menu-item-12" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/2">CSS/JAVASCRIPT/AJAX交流</a></li>
		<li id="menu-item-12" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/6">C/C++/JAVA交流</a></li>
		<li id="menu-item-12" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/4">官方公告</a></li>
		<li id="menu-item-12" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12">
		<a href="/ice4/index.php/Home/Bbs/board_list/id/3">ICECMS BUG提交</a></li>
</ul>
</li>



<li id="menu-item-13" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-13">
	<a href="/ice4/index.php/Home/Home">个人中心</a>
	<ul class="sub-menu">
	<li id="menu-item-16" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-16">
	<a href="/ice4/index.php/Home/Home/change">修改资料</a></li>
	<li id="menu-item-14" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-14">
	<a href="/ice4/index.php/Home/Home/zone/id<?php echo ($user_id); ?>">我的空间</a></li>
	</ul>
</li>


<li id="menu-item-6" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-6">
	<a href="">文章分享</a>
	<ul class="sub-menu">
		<li id="menu-item-22" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-22">
		<a href="/ice4/index.php/Home/Article/board_list/id/1">互联网</a></li>
		<li id="menu-item-7" class="menu-item menu-item-type-taxonomy menu-item-object-category current-menu-item menu-item-7">
		<a href="/ice4/index.php/Home/Article/board_list/id/2">编程感悟</a></li>
		<li id="menu-item-11" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11">
		<a href="/ice4/index.php/Home/Article/board_list/id/3">其他</a></li>
	</ul>
	</li>


	<li id="menu-item-374" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-374">
		<a href="/ice4/index.php/Home/Bbs/new_post">分类查看</a>
		<ul class="sub-menu">
			<li id="menu-item-19" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19">
			<a href="/ice4/index.php/Home/Bbs/new_post">最新帖子</a></li>
		</ul>
	</li>


	<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-24">
	<a href="/ice4/index.php/Home/Message/receive/">我的信息</a>
	<ul class="sub-menu">
		<li id="menu-item-66" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-66">
		<a href="/ice4/index.php/Home/Message/index">发送信息</a></li>
		<li id="menu-item-65" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-65">
		<a href="/ice4/index.php/Home/Message/sended">我已发送</a></li>
		<li id="menu-item-70" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70">
		<a href="/ice4/index.php/Home/Message/receive/">我已接收</a></li>
		<li id="menu-item-318" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-318">
		<a href="/ice4/index.php/Home/Message/atreceive">被@消息</a></li>
	</ul>
</li>
<li id="menu-item-69" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-69">
<a href="/ice4/index.php/Home/Bbs/add">发帖</a></li>
<li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-71">
<a href="/ice4/index.php/Home/Article/add">投稿</a></li>
<li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67">
<a href="http://icecms.cn/index.php/Home/bbs/read/id/82.html">ABOUT US</a></li>

<li style="float:right;">
<div class="toggle-search">
	<i class="fa fa-search">
	</i>
</div>
<div class="search-expand" style="display: none;">
	<div class="search-expand-inner">
		<form method="post" class="searchform" action="/ice4/index.php/Home/Bbs/search">
			<div>
	<input type="ext" class="search" name="content" value='输入内容并回车';" onfocus="if(this.value=='输入内容并回车')this.value='';" value="输入内容并回车">
			</div>
		</form>
	</div>
</div>
</li>
</ul>
</div>
</div>
</header>
<section class="container">
<div class="speedbar">
	<div class="pull-right">

		<?php
 if(!isset($_COOKIE['user_sid'])) echo '<i class="fa fa-power-off"></i> <a href="/ice4/index.php/Home/Login">登录</a>'; ?>		
	
	
	</div>
				<div class="toptip" id="callboard"><ul style="font-size:16px;margin-top: 2px;">程序员该有的情怀_如果没人支持,我一样可以走下去</ul></div>
	</div>
	
<div class="content-wrap">
	<div class="content">
		<header class="archive-header">
		TA的空间|<a href=/ice4/index.php/Home/Message/index/id/<?php echo ($user_id); ?>>发信息给TA</a>
		</header>
<ul class="user-titbox">
<div align="left" class="open-message">	<li class="title_bbs"><b>ID</b><span class="right"><?php echo ($user_id); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	用户名:</b><span class="right"><?php echo ($user_name); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	邮箱:</b><span class="right"><?php echo ($user_email); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	性别:</b><span class="right"><?php echo ($user_sex); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	积分:</b><span class="right"><?php echo ($user_integral); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	金币:</b><span class="right"><?php echo ($user_money); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	身份:</b><span class="right"><?php echo ($user_rank); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	回复总数:</b><span class="right"><?php echo ($user_respond_number); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	帖子总数:</b><span class="right"><?php echo ($user_theme_number); ?></span></li></div >
<div align="left" class="open-message">	<li class="title_bbs"><b>	个性签名:</b><span class="right"><?php echo ($user_character); ?></span></li></div >
</ul>
</div>
</div>


<aside class="sidebar">
<div class="widget widget_calendar"><div id="calendar_wrap">
		<table id="wp-calendar">
		一句话证明自己是程序员 <br>
程序员A：这个简单 ，Helloworld。<br>
程序员B：学生信息管理系统……<br>
程序员C：1+2==3<br>
程序员D：我的英语笔记：could you please to do sth.h<br>
	</table>
</div>
</div>
<div class="widget git_rec">
	<?php if(is_array($a_list)): $i = 0; $__LIST__ = $a_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 8 );++$i;?><a target="_blank" class="aclass0<?php echo ($mod+1); ?>" href="/ice4/index.php/Home/Article/read/id/<?php echo ($vo["article_id"]); ?>.html" title="<?php echo ($vo["article_title"]); ?>" ><?php echo ($vo["article_title"]); ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
	
<div class="widget git_tag">
	<div class="title">
		<h2>
			<a class="btn" target="_blank" href="">论坛分类</a>分类
		</h2>
	</div>
	<div class="git_tags">
		<a title="<?php echo ($count_1); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/1">杂谈茶楼</a>
		<a title="<?php echo ($count_5); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/5">WEB/PHP/ASP/C#</a>
		<a title="<?php echo ($count_2); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/2">CSS/JAVASCRIPT/AJAX</a>
		<a title="<?php echo ($count_6); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/6">C/C++/JAVA交流</a>
		<a title="<?php echo ($count_4); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/4">官方公告</a>
		<a title="<?php echo ($count_3); ?>个话题" target="_blank" href="/ice4/index.php/Home/Bbs/board_list/id/3">ICECMS BUG提交</a>
	</div>
	</div>
	<div class="widget widget_links">
		<div class="title">
			<h2>友情链接</h2>
		</div>
		<ul class='xoxo blogroll'>
			<li><a href="http://xiaows.com/" rel="friend co-worker neighbor crush" target="_blank">笑忘书</a></li>
			<li><a href="http://www.bingduba.com/" target="_blank">病毒吧</a></li>
		</ul>
	</div>


	<div class="widget widget_links">
		<div class="title">
			<h2>我们应该溜达一下</h2>
		</div>
	<ul class='xoxo blogroll'>
		<li><a href="http://thinkphp.cn/" target="_blank">THINKPHP</a></li>
		<li><a href="http://www.w3cschool.cc/" target="_blank">W3CSCHOOL</a></li>
		<li><a href="http://htmlpurifier.org/" target="_blank">htmlpurifier</a></li>
		<li><a href="http://kindeditor.net/" target="_blank">kindeditor</a></li>
	</ul>
</div>
<div class="widget git_comment">
	<div class="title">
		<h2>聊聊自己</h2>
</div>
<ul>
	<li><a target="_blank" href="">
		<img data-original="/ice4/Public/images/nohead.jpg" class="avatar avatar-72" height="50px" width="50px">
		<div class="muted">
			<i>ICE</i>
		只有我一个人知道，我不停地奔跑，即使没有任何人鼓励，我照样跑下去！
		</div>
           </a>
	</li>
</ul>
</div>
</aside>
</section>
<footer style="border-top: 1px solid ;background-image: url('/ice4/Public/webcss/footbg.jpg'); background-repeat: repeat;" class="footer">
<div class="footer-inner">
	<div class="footer-copyright" align="center">
		Copyright 2015   WWW.ICECMS.CN  | <a rel="nofollow" target="_blank" href="http://icecms.cn/index.php/Home/bbs/read/id/82.html">ABOUT US</a> | <a rel="nofollow" target="_blank" href="/ice4/index.php/Home/Home/dark_home.html">DARK HOUSE</a>
		
		<span class="trackcode pull-right"></span></div></div></footer>
<script type="text/javascript">(function(a){a.fn.snow=function(d){var g=a('<div id="snowbox" />').css({position:"absolute","z-index":"9999",top:"-50px"}).html("&#10052;"),f=a(document).height(),b=a(document).width(),e={minSize:10,maxSize:20,newOn:1000,flakeColor:"#FFF"},d=a.extend({},e,d);var c=setInterval(function(){var l=Math.random()*b-100,j=0.5+Math.random(),h=d.minSize+Math.random()*d.maxSize,i=f-200,k=l-500+Math.random()*500,m=f*10+Math.random()*5000;g.clone().appendTo("body").css({left:l,opacity:j,"font-size":h,color:d.flakeColor}).animate({top:i,left:k,opacity:0.2},m,"linear",function(){a(this).remove()})},d.newOn)}})(jQuery);$(function(){$.fn.snow({minSize:5,maxSize:50,newOn:300})});
</script><script type='text/javascript' src='/ice4/Public/webjs/global.js'></script>
</body>
</html>