<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="shortcut icon" href="16X16.ico" type="image/x-icon"><link rel="shortcut icon" href="16X16.ico" type="image/x-icon">
<style type="text/css">
body{word-wrap:break-word;word-break:break-all;margin:0px;padding:2px 1px 2px 1px;background-color:#FFFFFF;color:#000000;}p{margin:0px;padding:2px 1px 2px 1px;}
.tp{margin:0px;background-color:#E6F3FF;}
a{text-decoration:none;color:#08C;}
form{margin:0px;padding:0px;}
img{max -width:100%;}
hr{height:1px;border:1px solid #BED8EA;border-left:none;border-right:none;}
textarea{width:270px;height:55px;overflow-y:visible;}
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}
</style>

<title>管理员首页</title>

</head>
<body>
	
你好:<?php echo ($admin_name); ?>--简单而又粗暴的后台管理（一般人不会用哦）
<block name="body">
<br>
<div class="tp">1.网站配置</div>
<div class='box'>
	<form method="post" action=/ice4/admin.php/Home/Index/change>
		网站名称:<input name="status_title" type="text" value="<?php echo ($status_title); ?>"><br>
	<!--网站状态:<input name="status_status" type="text" value="<?php echo ($status_status); ?>">【1.为正常开放，2.禁言整个网站，3.禁言所有论坛，4.禁言聊天室】<br>-->
		网站描述:<input name="status_describe" type="text" value="<?php echo ($status_describe); ?>"><br>
		网站的关键字:<input name="status_key" type="text" value="<?php echo ($status_key); ?>"><br>
		<!--网站公告:<input name="status_announce" type="text" value="<?php echo ($status_announce); ?>"><br>-->
		<!--是否开启防范ddos:<input name="status_ddos" type="text" value="<?php echo ($status_ddos); ?>">【1为开启，0为关闭】<br>
		防止ddos的10秒内最多可以刷新几次:<input name="status_ddos_times" type="text" value="<?php echo ($status_ddos_times); ?>"><br>-->
		发帖赠送的积分数:<input name="s_integral" type="text" value="<?php echo ($s_integral); ?>"><br>
		发帖赠送的金币数:<input name="s_money" type="text" value="<?php echo ($s_money); ?>"><br>
		回帖赠送的金币数:<input name="r_money" type="text" value="<?php echo ($r_money); ?>"><br>
		回帖赠送的积分数:<input name="r_integral" type="text" value="<?php echo ($r_integral); ?>"><br>
		附件上传的最大大小:为php.ini配置里面的大小<br>
		<!--附件上传的最大大小:<input name="f" type="text" value="<?php echo ($f); ?>">字节为单位<br>-->
		注册方式:<input name="reg_method" type="text" value="<?php echo ($reg_method); ?>">【1.普通注册,4.关闭注册】<br>
		网站底部内容:<textarea name="website_foot" rows="2" cols="30" ><?php echo ($website_foot); ?></textarea><br>
		<input name="submit" type="submit" value="修改">
	</form >
</div>
<hr/>
<div class="tp">2.操作用户</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/change_user>
	输入用户ID:<input name="id" type="text"><br>
		<input name="submit" type="submit" value="操作">
	</form >
</div>

<hr/>
<div class="tp">3.操作帖子(ID为帖子链接上面的id/xxx)</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/change_post>
	输入帖子ID:<input name="id" type="text"><br>
		<input name="submit" type="submit" value="操作">
	</form >
</div>

<hr/>
<div class="tp">4.操作文章(ID为文章链接上面的id/xxx)</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/change_article>
	输入文章ID:<input name="id" type="text"><br>
		<input name="submit" type="submit" value="操作">
	</form >
</div>

<hr/>
<div class="tp">5.论坛版块</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/add_bbs_board>
	输入版块名称:
	<input name="name" type="text"><br>
	<input name="submit" type="submit" value="增加">
</form >
	<?php if(is_array($b_board_arr_)): $i = 0; $__LIST__ = $b_board_arr_;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><form method="post" action=/ice4/admin.php/Home/Index/change_bbs_board>
			版块名称:<input name="name" type="text" value="<?php echo ($vo["bbs_board_name"]); ?>"/>
			<input name="id" type="hidden" value="<?php echo ($vo["bbs_board_id"]); ?>"/>【ID:<?php echo ($vo["bbs_board_id"]); ?>】
			<input name="submit" type="submit" value="修改">
		</form ><?php endforeach; endif; else: echo "" ;endif; ?>
</div>


<hr/>
<div class="tp">5.文章版块</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/add_article_board>
	输入版块名称:
	<input name="name" type="text"><br>
	<input name="submit" type="submit" value="增加">
</form >
	<?php if(is_array($a_board_arr_)): $i = 0; $__LIST__ = $a_board_arr_;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><form method="post" action=/ice4/admin.php/Home/Index/change_article_board>
			版块名称:<input name="name" type="text" value="<?php echo ($vo["article_board_name"]); ?>"/>
			<input name="id" type="hidden" value="<?php echo ($vo["article_board_id"]); ?>"/>【ID:<?php echo ($vo["article_board_id"]); ?>】
			<input name="submit" type="submit" value="修改">
		</form ><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<hr/>
<div class="tp"><a href=/ice4/admin.php/Home/Index/article_list>7.待审核文章</a>（<?php echo ($article_c); ?>篇待审）</div>
<hr/>
<div class="tp"><a href=/ice4/admin.php/Home/Index/add_article>8.后台增加文章</a></div>
<hr/>
<div class="tp">无敌后台</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/sql>
	sql语句:<textarea name="sql" rows="2" cols="30" placeholder="SQL语句"></textarea><br>
		<input name="submit" type="submit" value="执行">
	</form >
</div>
<hr/>
<div class="tp">修改管理员密码</div>
<div class='box'>
<form method="post" action=/ice4/admin.php/Home/Index/change_admin_pwd>
	新管理员密码:<input name="content" rows="2" cols="30" placeholder="请输入新密码"><br>
		<input name="submit" type="submit" value="执行">
	</form >
</div>
<a href="http://icecms.cn">ICECMS</a>

</body>
</html>