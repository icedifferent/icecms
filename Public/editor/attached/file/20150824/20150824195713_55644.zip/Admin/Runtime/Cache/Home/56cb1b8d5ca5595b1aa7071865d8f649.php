<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="shortcut icon" href="16X16.ico" type="image/x-icon"><link rel="shortcut icon" href="16X16.ico" type="image/x-icon">
<style type="text/css">
body{word-wrap:break-word;word-break:break-all;margin:0px;padding:2px 1px 2px 1px;background-color:#FFFFFF;color:#000000;}p{margin:0px;padding:2px 1px 2px 1px;}
.tp{margin:0px;background-color:#E6F3FF;}
a{text-decoration:none;color:#08C;}
form{margin:0px;padding:0px;}
img{max -width:100%;}
hr{height:1px;border:1px solid #BED8EA;border-left:none;border-right:none;}
textarea{width:270px;height:55px;overflow-y:visible;}
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}
</style>

<title>首页</title>

</head>
<body>
	
<br>
<div class="tp">帖子信息修改</div>
<div class='box'>
	<form method="post" action=/ice4/admin.php/Home/Index/change_post_do>
		帖子标题:<input name="post_title" type="text" value="<?php echo ($post_title); ?>"><br>
		帖子内容:<textarea name="post_content" rows="2" cols="30" ><?php echo ($post_content); ?></textarea><br>
		帖子版块id:<input name="post_board_id" type="text" value="<?php echo ($post_board_id); ?>"><br>
		帖子浏览量:<input name="post_hot" type="text" value="<?php echo ($post_hot); ?>"><br>
		帖子状态:<input name="post_status" type="text" value="<?php echo ($post_status); ?>">【0.被锁定，禁止回复，可查看。2.被屏蔽内容。3.被删除。4.被置顶.5被加精】<br>
			<input name="id" type="hidden" value="<?php echo ($post_id); ?>"><br>
		<input name="submit" type="submit" value="修改">
	</form >
</div>

</body>
</html>