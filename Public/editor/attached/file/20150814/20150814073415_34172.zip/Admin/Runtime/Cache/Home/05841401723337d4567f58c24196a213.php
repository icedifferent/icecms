<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="shortcut icon" href="16X16.ico" type="image/x-icon"><link rel="shortcut icon" href="16X16.ico" type="image/x-icon">
<style type="text/css">
body{word-wrap:break-word;word-break:break-all;margin:0px;padding:2px 1px 2px 1px;background-color:#FFFFFF;color:#000000;}p{margin:0px;padding:2px 1px 2px 1px;}
.tp{margin:0px;background-color:#E6F3FF;}
a{text-decoration:none;color:#08C;}
form{margin:0px;padding:0px;}
img{max -width:100%;}
hr{height:1px;border:1px solid #BED8EA;border-left:none;border-right:none;}
textarea{width:270px;height:55px;overflow-y:visible;}
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}
</style>

<title><?php echo ($title); ?></title>

</head>
<body>
	
<div class="tp"><?php echo ($title); ?></div>
<hr>
<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 20 );++$i; echo ($mod+1); ?>
：ID:<?php echo ($vo["article_id"]); ?>|<?php echo ($vo["article_title"]); ?>
<br>作者:<?php echo ($vo["article_ower_id"]); ?>|<?php echo ($vo["article_ower_name"]); ?>
(<?php echo ($vo["article_date"]); ?>)<hr><?php endforeach; endif; else: echo "" ;endif; ?>
<?php echo ($page); ?>
<a href="/ice4/admin.php/Home/Index">返回</a>
<hr>

</body>
</html>