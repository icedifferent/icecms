<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="shortcut icon" href="16X16.ico" type="image/x-icon"><link rel="shortcut icon" href="16X16.ico" type="image/x-icon">
<style type="text/css">
body{word-wrap:break-word;word-break:break-all;margin:0px;padding:2px 1px 2px 1px;background-color:#FFFFFF;color:#000000;}p{margin:0px;padding:2px 1px 2px 1px;}
.tp{margin:0px;background-color:#E6F3FF;}
a{text-decoration:none;color:#08C;}
form{margin:0px;padding:0px;}
img{max -width:100%;}
hr{height:1px;border:1px solid #BED8EA;border-left:none;border-right:none;}
textarea{width:270px;height:55px;overflow-y:visible;}
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}
</style>

<title>首页</title>

</head>
<body>
	
<br>
<div class="tp">文章信息修改</div>
<div class='box'>
	<form method="post" action=/ice4/admin.php/Home/Index/change_article_do>
		文章标题:<input name="article_title" type="text" value="<?php echo ($article_title); ?>"><br>
		文章内容:<textarea name="article_content" rows="2" cols="30" ><?php echo ($article_content); ?></textarea><br>
		文章浏览量:<input name="article_hot" type="text" value="<?php echo ($article_hot); ?>"><br>
		文章状态:<input name="article_status" type="text" value="<?php echo ($article_status); ?>"><br>
【0.被锁定，禁止回复，可查看。1.正常 2.被屏蔽内容。
3.被删除。5.被置顶.6被加精】<br>
		文章版块ID:<input name="article_board_id" type="text" value="<?php echo ($article_board_id); ?>"><br>
		文章赞:<input name="article_praise_times" type="text" value="<?php echo ($article_praise_times); ?>"><br>
		文章贬:<input name="article_lookdown_times" type="text" value="<?php echo ($article_lookdown_times); ?>"><br>
		<input name="id" type="hidden" value="<?php echo ($article_id); ?>"><br>
		<input name="submit" type="submit" value="修改">
	</form >
</div>

</body>
</html>