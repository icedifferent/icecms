<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />
<link rel="shortcut icon" href="16X16.ico" type="image/x-icon"><link rel="shortcut icon" href="16X16.ico" type="image/x-icon">
<style type="text/css">
body{word-wrap:break-word;word-break:break-all;margin:0px;padding:2px 1px 2px 1px;background-color:#FFFFFF;color:#000000;}p{margin:0px;padding:2px 1px 2px 1px;}
.tp{margin:0px;background-color:#E6F3FF;}
a{text-decoration:none;color:#08C;}
form{margin:0px;padding:0px;}
img{max -width:100%;}
hr{height:1px;border:1px solid #BED8EA;border-left:none;border-right:none;}
textarea{width:270px;height:55px;overflow-y:visible;}
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}
</style>

<title>首页</title>

</head>
<body>
	
<br>
<div class="tp">用户信息修改</div>
<div class='box'>
	<form method="post" action=/ice4/admin.php/Home/Index/change_user_do>
	用户名:<input name="user_name" type="text" value="<?php echo ($user_name); ?>"><br>
	EMAIL:<input name="user_email" type="text" value="<?php echo ($user_email); ?>"><br>
	PHONE:<input name="user_phone" type="text" value="<?php echo ($user_phone); ?>"><br>
	SEX:<input name="user_sex" type="text" value="<?php echo ($user_sex); ?>"><br>
	头像地址:<input name="user_img" type="text" value="<?php echo ($user_img); ?>"><br>
	状态:<input name="user_status" type="text" value="<?php echo ($user_status); ?>">
	【0.未激活，1.普通用户，3.已经被禁言论坛发帖，4.总版主（删帖和修改帖子权限），5.管理员,6禁言聊天室，7，被禁言论坛回帖，8.被禁言所有，包括修改信息等，2.被禁止修改个人信息】<br>
	签名:<textarea name="user_character" rows="2" cols="30" placeholder="签名"><?php echo ($user_character); ?></textarea><br>
	违规内容:<input name="user_violations_content" type="text" value="<?php echo ($user_violations_content); ?>"><br>
	钱:<input name="user_money" type="text" value="<?php echo ($user_money); ?>"><br>
	密码:<input name="user_password" type="text" value="<?php echo ($user_password); ?>"><br>
	积分:<input name="user_integral" type="text" value="<?php echo ($user_integral); ?>"><br>
	等级:<input name="user_rank" type="text" value="<?php echo ($user_rank); ?>"><br>
	空间代码:<input name="user_zone" type="text" value="<?php echo ($user_zone); ?>"><br>
		<input name="id" type="hidden" value="<?php echo ($user_id); ?>"><br>
		<input name="submit" type="submit" value="修改">
	</form >
</div>


</body>
</html>