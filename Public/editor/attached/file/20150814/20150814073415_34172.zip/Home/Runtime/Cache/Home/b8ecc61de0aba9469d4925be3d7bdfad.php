<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8"/>
<meta http-equiv="Content-Language" content="zh-CN"/>
<meta name=Copyright Content="本程序版权归ICE所有"/> 
<meta name="Author-Corporation" content="ICE,2015"/>
<meta name="description" content="ICECMS,PHP的讨论和交流"/>
<meta name="keywords" content="编程|PHP|C语言|c++|java|ice|icecms"/>
<link rel="icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Cache-Control" content="must-revalidate,no-cache"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" type="text/css" href="/ice4/Public/css/home.css"/>
<link rel="stylesheet" type="text/css" href="/ice4/Public/css/bbs.css"/>
<link rel="stylesheet" type="text/css" href="/ice4/Public/css/box.css"/>
<script src="/ice4/Public/js/jquery.js"></script>
<script src="/ice4/Public/js/box.js"></script>

<title><?php echo ($title); ?></title>

</head>
<script language ="javascript" type ="text/javascript">
function atAdd(at){
	var content =document.getElementsByName("content")[0]
		//	content.value+="@"+at+",";
		editor.html(editor.text()+'@'+at+",");
}


function urlAdd(){
	var content =document.getElementsByName("content")[0];
	//content.value+="[url=http://链接地址]点击访问[/url]";
	editor.html(editor.text()+"[url=http://链接地址]点击访问[/url]");
}


function imgAdd(){
	var content =document.getElementsByName("content")[0];
	//content.value+="[img]http://图片地址[/img]";
	editor.html(editor.text()+"[img]http://图片地址[/img]");

}


function codeAdd(){
	var content =document.getElementsByName("content")[0];
	//content.value+="[code]//请在这里输入代码[/code]";
	editor.html(editor.text()+"[code]//请在这里输入代码[/code]");
}



</script>
<style>
input[id=number]{
width:60px;
height:25px;
border-width: 1px;
border-style: solid;
color:#d7d7d7;
}</style>
<body>

	
<div class="bbs_head">标题：<?php echo ($title); ?></div>
【回复列表】
<hr>
<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 20 );++$i; if($mod%2 != 0): ?><div class="bbs_ping_title">
	<?php else: ?>
	<div class="bbs_ping_title_two"><?php endif; ?>

<?php echo ($count-$i+1); ?>楼:<a href=/ice4/index.php/Home/Home/zone/id/<?php echo ($vo["respond_user_id"]); ?>.html><span style="color:#FFABAB"><?php echo ($vo["respond_user_name"]); ?></span></a>//(ID:<?php echo ($vo["respond_user_id"]); ?>):<?php echo ubb($vo["respond_content"]);?><br>
<span class="right"><?php echo ($vo["respond_time"]); ?></span></div><?php endforeach; endif; else: echo "" ;endif; ?>
<?php echo ($page); ?>
<a href="/ice4/index.php/Home/Bbs/read/id/<?php echo ($post_id); ?>">返回</a>
<hr>

	<div class="foot"><a href="/ice4/index.php/Home/Index/index">首页</a>&nbsp;<a href="/ice4/index.php/Home/Bbs/index">论坛</a>&nbsp;<a href="/ice4/index.php/Home/Article/index">文章</a>&nbsp;<a href="/ice4/index.php/Home/Bbs/add">发帖</a>&nbsp;<a href="/ice4/index.php/Home/Article/add">投稿</a>&nbsp;<a href="/ice4/index.php/Home/Home/dark_home">小黑屋</a>
		<br />Copyright 2015 ICECMS.CN |<a href="http://icecms.cn/index.php/Home/bbs/read/id/82.html">ABOUT US</a>

</div>
</body>
</html>