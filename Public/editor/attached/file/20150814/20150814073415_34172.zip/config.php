<?php
return array(
	//'配置项'=>'配置值'
	// 添加数据库配置信息
 'DB_TYPE'   => 'mysql', // 数据库类型
 'DB_HOST'   => 'localhost', // 服务器地址
 'DB_NAME'   => 'icebbs', // 数据库名
 'DB_USER'   => 'root', // 用户名
 'DB_PWD'    => 'root', // 密码
 'DB_PORT'   => 3306, // 端口
 'DB_PREFIX' => 'icebbs_', // 数据库表前缀（一般不需要修改）
 'DEFAULT_TIMEZONE' => 'PRC', // 默认时区
'TMPL_L_DELIM'=>'<{', //修改左定界符
'TMPL_R_DELIM'=>'}>', //修改右定界符
//'SHOW_PAGE_TRACE'=>true,//开启页面Trace
);


