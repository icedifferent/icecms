<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ICECMS留言板</title>
</head>

<body>
<?php
echo '//仅供学习,没做任何安全<br/>
//非实用<br/>
//大神就别BB了<br/>
//这是给小白看的<br/>
//@作者：ice<br/>
//@官网：http://icecms.cn<br/>
//@联系方式：QQ:742820157<br/>
//MYSQL类下载：进官网搜索 mysql<br/>';
 
include "conn.php";//链接数据库
include "sql.class.php";//引入mysql类；可以到http://icecms.cn搜索下载
echo'<form method="post" action="index.php" >
	<input name="user" type="txt" value="你的姓名"/><br/>
	<input name="content" type="txt" value="留言内容"/>
	<input name="submit" type="submit" value="留言">
</form>';
$u=new sql("content");
if(isset($_POST['submit'])){
	$data['user']=$_POST['user'];
	$data['content']=$_POST['content'];
	$count=$u->add($data);
	if($count){
		echo '留言成功<br/>';
	}else{
	echo 'error';
	}
}
echo '留言ICECMS,学习专用:<br>';
//下面是显示留言内容
//测试学习用的，不做分页之类的啦
$arr=$u->select();
$i=1;
foreach($arr as $arr1){
	echo $i.".昵称：".$arr1['user']."<br/ > 留言内容:".$arr1['content']."<hr >";
	$i++;
}
echo "http://icecms.cn";
?>
</body>
</html>

